from app import db
from models import User, Post, ROLE_USER, ROLE_CREATOR, ROLE_ADMIN
import logging


def create_sample_posts():
    """
    Cria usuários e postagens de exemplo com temas relacionados ao projeto Dois de Muitos:
    natureza, proteção ambiental, permacultura, agroecologia, artes, teatro e artesanato.
    Deve ser executada dentro do contexto da aplicação.
    """
    # Recarregar os dados toda vez que o aplicativo iniciar
    if Post.query.count() > 0:
        logging.info("Limpando posts existentes no banco")
        Post.query.delete()
        User.query.delete()
        db.session.commit()

    logging.info("Criando postagens de exemplo para o fórum Dois de Muitos")

    # Criando um usuário admin com permissões totais
    admin = User()
    admin.username = "admin"
    admin.email = "admin@doisdemuitos.org"
    admin.set_password("admin123")  # Em produção, usaria uma senha forte
    admin.role = ROLE_ADMIN
    db.session.add(admin)

    # Criando usuários regulares com diferentes níveis de permissão
    users = [("guardiao_verde", "verde@example.com", "hashed1", ROLE_CREATOR),
             ("arte_ancestral", "artes@example.com", "hashed2", ROLE_CREATOR),
             ("caminhante_agroecologico", "agroecologia@example.com",
              "hashed3", ROLE_CREATOR),
             ("teatro_raiz", "teatro@example.com", "hashed4", ROLE_USER),
             ("feira_sustentavel", "artesanato@example.com", "hashed5",
              ROLE_USER)]

    for username, email, password, role in users:
        user = User()
        user.username = username
        user.email = email
        user.set_password(password)
        user.role = role
        db.session.add(user)

    try:
        db.session.commit()
        logging.info("Usuários de exemplo criados")
    except Exception as e:
        db.session.rollback()
        logging.error(f"Erro ao criar usuários: {str(e)}")
        return

    # Buscar os usuários do banco de dados para associar posts
    users_dict = {}
    for user in User.query.all():
        users_dict[user.username] = user.id

    # Guardar o ID do usuário admin
    admin_id = User.query.filter_by(username="admin").first().id

    posts = [
        # Primeiro post do admin
        Post(
            title="Bem-vindos ao Fórum Dois de Muitos",
            content=
            "Este é um espaço para compartilhar conhecimentos sobre permacultura, agroecologia, artes e saberes tradicionais. Sintam-se à vontade para participar!",
            user_id=admin_id),

        # Posts dos outros usuários
        Post(
            title="Como iniciar um projeto de permacultura em pequena escala?",
            content=
            "Quais os primeiros passos para aplicar os princípios da permacultura em um terreno de 1 hectare? Quais são os erros mais comuns para iniciantes?",
            user_id=users_dict["guardiao_verde"]),
        Post(
            title="Rituais e saberes ancestrais na arte contemporânea",
            content=
            "Alguém aqui já participou de projetos que integram expressões culturais tradicionais com linguagens artísticas modernas? Busco referências para um espetáculo multimídia inspirado em mitos da floresta.",
            user_id=users_dict["arte_ancestral"]),
        Post(
            title="Adubação natural: como fazer biofertilizantes caseiros?",
            content=
            "Estou começando uma horta agroecológica e quero evitar insumos industrializados. Quais receitas vocês recomendam para fazer biofertilizantes e compostos naturais?",
            user_id=users_dict["caminhante_agroecologico"]),
        Post(
            title="Teatro como ferramenta de educação ambiental",
            content=
            "Tenho interesse em desenvolver peças teatrais que promovam consciência ecológica. Alguém tem experiência com teatro fórum ou teatro do oprimido voltado à sustentabilidade?",
            user_id=users_dict["teatro_raiz"]),
        Post(
            title=
            "Artesanato com reaproveitamento: ideias para oficinas comunitárias",
            content=
            "Quais tipos de materiais reaproveitados funcionam melhor em oficinas com crianças e adultos? Estou montando um projeto de arte e renda para mulheres em zona rural.",
            user_id=users_dict["feira_sustentavel"]),
        Post(
            title=
            "Como planejar uma agrofloresta biodiversa na Mata Atlântica?",
            content=
            "Quero dicas de espécies nativas e estratégias de estratificação para criar um sistema agroflorestal que respeite o bioma local. Sugestões de combinações produtivas?",
            user_id=users_dict["caminhante_agroecologico"]),
        Post(
            title="O papel da arte na regeneração de territórios",
            content=
            "Tenho estudado como murais, música e poesia podem ajudar na cura coletiva de comunidades em transição. Alguém conhece projetos inspiradores nessa linha?",
            user_id=users_dict["arte_ancestral"]),
        Post(
            title=
            "Feiras sustentáveis: como organizar trocas e exposições locais?",
            content=
            "Estamos organizando uma feira mensal com trocas, apresentações artísticas e produtos da roça. Ideias de estrutura, divulgação e atividades intergeracionais são bem-vindas!",
            user_id=users_dict["feira_sustentavel"]),
        Post(
            title="Vida simples no campo: desafios e aprendizados",
            content=
            "Depois de 8 meses vivendo em uma ecovila, compartilho reflexões sobre coletividade, cuidado com a terra e autonomia. Quem mais aqui já viveu algo parecido?",
            user_id=users_dict["guardiao_verde"]),
        Post(
            title="Teatro ritual e celebrações da natureza",
            content=
            "Busco referências de encenações ou vivências que celebrem os ciclos da terra, como solstícios e equinócios, integrando música, corpo e espiritualidade.",
            user_id=users_dict["teatro_raiz"]),
        Post(
            title="Construções naturais: tecnologias para bioconstrução",
            content=
            "Estou planejando uma construção usando técnicas de bioconstrução. Alguém tem experiência com superadobe, taipa de mão ou pau-a-pique no clima tropical? Quais técnicas são mais duráveis durante a estação chuvosa?",
            user_id=users_dict["guardiao_verde"]),
        Post(
            title="Sementes crioulas: preservação e troca",
            content=
            "Estamos organizando um banco de sementes comunitário e buscamos parceiros para troca de variedades crioulas. Alguém aqui guarda e multiplica sementes adaptadas à sua região? Vamos conectar guardiões de sementes!",
            user_id=users_dict["caminhante_agroecologico"]),
        Post(
            title="Danças circulares e saberes tradicionais",
            content=
            "Como podemos integrar danças circulares de diferentes culturas em trabalhos de reconexão comunitária? Procuro repertório de cantos e danças que celebrem a terra e os elementos naturais.",
            user_id=users_dict["arte_ancestral"]),
        Post(
            title="Captação e manejo sustentável de água",
            content=
            "Quais sistemas de captação de água da chuva têm funcionado melhor em áreas rurais? Estou projetando um sistema integrado com açudes, swales e cisternas. Dicas para dimensionamento?",
            user_id=users_dict["guardiao_verde"]),
        Post(
            title="Ervas medicinais e saberes populares",
            content=
            "Quem tem experiência com cultivo de farmácia viva e processamento de ervas medicinais? Estamos resgatando saberes de plantas locais e buscamos informações sobre preparos tradicionais.",
            user_id=users_dict["feira_sustentavel"]),
        Post(
            title="Integração de animais em sistemas agroflorestais",
            content=
            "Como integrar galinhas, abelhas e outros pequenos animais em um sistema agroflorestal jovem? Quais cuidados tomar para que os animais contribuam sem prejudicar as plantas?",
            user_id=users_dict["caminhante_agroecologico"]),
        Post(
            title="Técnicas de facilitação para encontros comunitários",
            content=
            "Busco métodos eficientes para facilitar reuniões e tomadas de decisão em grupos heterogêneos. Como lidar com conflitos e criar espaços seguros para que todos se expressem?",
            user_id=users_dict["teatro_raiz"]),
        Post(
            title="Arte têxtil com fibras e tintas naturais",
            content=
            "Alguém trabalha com tecelagem e tingimento natural? Quero aprender sobre extração sustentável de fibras locais e corantes vegetais que não agridam o meio ambiente.",
            user_id=users_dict["arte_ancestral"]),
        Post(
            title="Fogões eficientes e energia limpa",
            content=
            "Estamos pesquisando alternativas para fogões rocket, biodigestor e outras tecnologias de baixo impacto para cozinhas coletivas. Quais experiências têm sido mais duradouras?",
            user_id=users_dict["feira_sustentavel"]),
        Post(
            title="Mutirões agroecológicos: como organizar",
            content=
            "Quais as melhores práticas para organizar mutirões produtivos e educativos em agroecologia? Como equilibrar trabalho, aprendizado e celebração para que todos saiam satisfeitos?",
            user_id=users_dict["caminhante_agroecologico"])
    ]

    for post in posts:
        db.session.add(post)

    try:
        db.session.commit()
        logging.info(f"{len(posts)} postagens de exemplo criadas")
    except Exception as e:
        db.session.rollback()
        logging.error(f"Erro ao criar postagens: {str(e)}")
