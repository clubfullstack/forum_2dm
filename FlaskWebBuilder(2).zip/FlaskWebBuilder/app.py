import os
import logging
import shutil
from datetime import datetime

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from flask_login import LoginManager

import csv

# Configure logging
logging.basicConfig(level=logging.DEBUG)


class Base(DeclarativeBase):
    pass


db = SQLAlchemy(model_class=Base)

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev_secret_key")

# Configure the database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Initialize the app with the extension
db.init_app(app)

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Por favor, faça login para acessar esta página.'
login_manager.login_message_category = 'warning'


@login_manager.user_loader
def load_user(user_id):
    from models import User
    return User.query.get(int(user_id))


def export_data_to_csv():
    """Exporta os dados dos usuários e posts para arquivos CSV"""
    from models import User, Post
    export_folder = 'exports'
    os.makedirs(export_folder, exist_ok=True)

    with open(os.path.join(export_folder, 'users.csv'),
              'w',
              newline='',
              encoding='utf-8') as f:
        writer = csv.DictWriter(f,
                                fieldnames=['id', 'username', 'email', 'role'])
        writer.writeheader()
        for user in User.query.all():
            writer.writerow({
                'id': user.id,
                'username': user.username,
                'email': user.email,
                'role': user.role,
            })

    with open(os.path.join(export_folder, 'posts.csv'),
              'w',
              newline='',
              encoding='utf-8') as f:
        writer = csv.DictWriter(
            f, fieldnames=['id', 'title', 'content', 'timestamp', 'author'])
        writer.writeheader()
        for post in Post.query.all():
            writer.writerow(post.to_dict())


def backup_database():
    """Cria um backup do arquivo do banco de dados SQLite, se for o caso"""
    db_url = app.config["SQLALCHEMY_DATABASE_URI"]
    if db_url and db_url.startswith("sqlite:///"):
        db_path = db_url.replace("sqlite:///", "")
        if os.path.exists(db_path):
            backup_folder = "backups"
            os.makedirs(backup_folder, exist_ok=True)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = os.path.join(backup_folder,
                                       f"backup_{timestamp}.sqlite")
            shutil.copy2(db_path, backup_path)
            logging.info(f"Backup do banco criado em: {backup_path}")
        else:
            logging.warning(
                f"Arquivo de banco de dados não encontrado: {db_path}")


with app.app_context():
    import models
    from models import User

    # Backup antes de qualquer modificação
    backup_database()

    # Criar tabelas se não existirem
    db.create_all()

    # Popular com dados de amostra se estiver vazio
    if User.query.count() == 0:
        import sample_data
        sample_data.create_sample_posts()

    # Exportar automaticamente para CSV
    export_data_to_csv()
