# Mini Forum Dois de muitos

Um fórum inteligente que permite aos usuários pesquisar posts similares com base em consultas de texto, utilizando pontuação de similaridade para exibir os resultados mais relevantes.

## Funcionalidades

- **Pesquisa Inteligente**: Encontre posts relacionados ao seu texto usando processamento de linguagem natural
- **Pontuação de Similaridade**: Resultados classificados com porcentagem de relevância
- **Banco de Dados PostgreSQL**: Armazenamento persistente de dados
- **Interface Responsiva**: Design adaptável usando Bootstrap
- **Adição de Posts**: Interface amigável para adicionar novos conteúdos ao fórum

## Tecnologias Utilizadas

- **Backend**: Python + Flask
- **Frontend**: HTML, CSS, JavaScript, Bootstrap
- **Processamento de Texto**: TF-IDF e similaridade de cosseno via Scikit-learn
- **Banco de Dados**: PostgreSQL
- **Análise de Dados**: Pandas e NumPy

## Como Executar

1. Clone o repositório
2. Instale as dependências: `pip install -r requirements.txt`
3. Configure as variáveis de ambiente para o banco de dados PostgreSQL
4. Execute a aplicação: `gunicorn --bind 0.0.0.0:5000 --reuse-port --reload main:app`

## Estrutura do Projeto

- `main.py` - Ponto de entrada da aplicação
- `app.py` - Configuração do Flask e banco de dados
- `models.py` - Modelos de dados (ORM)
- `routes.py` - Rotas e controladores da aplicação
- `post_similarity.py` - Lógica de processamento de similaridade de texto
- `templates/` - Arquivos HTML usando Jinja2
- `static/` - Arquivos estáticos (CSS, JavaScript)

## Próximos Passos

- Implementação de autenticação de usuários
- Categorização de posts
- Recursos de comentários e interação
- Melhorias no algoritmo de similaridade

---

Desenvolvido com 💡 - Mini Fórum Dois de muitos