/**
 * Mini Forum Dois de muitos - Main JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize Bootstrap tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Search form validation
    const searchForm = document.getElementById('search-form');
    if (searchForm) {
        searchForm.addEventListener('submit', function(event) {
            const queryField = document.getElementById('query');
            
            if (!queryField.value.trim()) {
                event.preventDefault();
                // Add error styling
                queryField.classList.add('is-invalid');
                
                // Create error message if it doesn't exist
                if (!document.getElementById('query-error')) {
                    const errorFeedback = document.createElement('div');
                    errorFeedback.id = 'query-error';
                    errorFeedback.className = 'invalid-feedback';
                    errorFeedback.textContent = 'Please enter a search query';
                    queryField.parentNode.appendChild(errorFeedback);
                }
            } else {
                // Remove error styling if valid
                queryField.classList.remove('is-invalid');
            }
        });
        
        // Remove error styling on input
        const queryField = document.getElementById('query');
        if (queryField) {
            queryField.addEventListener('input', function() {
                if (this.value.trim()) {
                    this.classList.remove('is-invalid');
                }
            });
        }
    }
    
    // Auto-resize textarea as user types
    const textareas = document.querySelectorAll('textarea');
    textareas.forEach(textarea => {
        textarea.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = (this.scrollHeight) + 'px';
        });
    });
});
