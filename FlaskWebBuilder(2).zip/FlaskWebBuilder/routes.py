from flask import render_template, request, jsonify, flash, redirect, url_for, session
from app import app, db
from models import Post, User, ROLE_USER, ROLE_CREATOR, ROLE_ADMIN
from post_similarity import get_similar_posts
from flask_login import login_user, logout_user, login_required, current_user
import logging
from datetime import datetime
from functools import wraps


# Decorator para verificar se o usuário pode criar posts
def creator_required(f):

    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            flash('Por favor, faça login para acessar esta página.', 'warning')
            return redirect(url_for('login', next=request.url))
        if not current_user.can_create_posts():
            flash('Você não tem permissão para criar posts.', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)

    return decorated_function


# Decorator para verificar se o usuário é administrador
def admin_required(f):

    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            flash('Por favor, faça login para acessar esta página.', 'warning')
            return redirect(url_for('login', next=request.url))
        if not current_user.is_admin():
            flash('Você precisa ser administrador para acessar esta página.',
                  'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)

    return decorated_function


@app.route('/')
def index():
    """Render the main page with search form"""
    return render_template('index.html')


@app.route('/new-post', methods=['GET', 'POST'])
def new_post():
    """Add a new post to the database"""
    users = User.query.all()

    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        content = request.form.get('content', '').strip()
        user_id = request.form.get('user_id')

        if not title or not content or not user_id:
            flash('Please fill all the required fields', 'warning')
        else:
            try:
                user_id = int(user_id)
                post = Post(title=title,
                            content=content,
                            timestamp=datetime.utcnow(),
                            user_id=user_id)
                db.session.add(post)
                db.session.commit()
                flash('Post added successfully!', 'success')
                return redirect(url_for('view_posts'))
            except Exception as e:
                db.session.rollback()
                logging.error(f"Error adding post: {str(e)}")
                flash(f'Error adding post: {str(e)}', 'danger')

    return render_template('new_post.html', users=users)


@app.route('/posts')
def view_posts():
    """View all posts"""
    posts = Post.query.order_by(Post.timestamp.desc()).all()
    return render_template('view_posts.html', posts=posts)


@app.route('/search', methods=['POST'])
def search():
    """Handle search requests and display results"""
    query = request.form.get('query', '').strip()

    if not query:
        flash('Please enter a search query', 'warning')
        return redirect(url_for('index'))

    try:
        # Get number of results to return (default to 5)
        num_results = int(request.form.get('num_results', 5))
        if num_results < 1:
            num_results = 5
    except ValueError:
        num_results = 5

    try:
        # Get similar posts with similarity scores
        results = get_similar_posts(query, num_results)

        # Log the results for debugging
        logging.debug(f"Search query: {query}")
        logging.debug(f"Number of results: {len(results)}")

        return render_template('search_results.html',
                               query=query,
                               results=results,
                               num_results=num_results)
    except Exception as e:
        logging.error(f"Error searching for posts: {str(e)}")
        flash(f'An error occurred while searching: {str(e)}', 'danger')
        return redirect(url_for('index'))


@app.route('/api/posts')
def get_posts():
    """API endpoint to get all posts (for debugging)"""
    posts = Post.query.all()
    return jsonify([post.to_dict() for post in posts])


@app.errorhandler(404)
def page_not_found(e):
    return render_template('index.html', error="Page not found"), 404


@app.errorhandler(500)
def server_error(e):
    return render_template('index.html', error="Server error occurred"), 500
