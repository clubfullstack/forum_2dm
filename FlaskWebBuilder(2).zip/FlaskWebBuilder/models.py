from datetime import datetime
from app import db
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin

# Definir constantes para níveis de permissão
ROLE_USER = 0  # Usuário regular (só pode ler)
ROLE_CREATOR = 1  # Pode criar posts
ROLE_ADMIN = 2  # Acesso completo


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256))
    role = db.Column(db.Integer,
                     default=ROLE_USER)  # Permissão padrão: somente leitura
    posts = db.relationship('Post', backref='author', lazy='dynamic')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def is_admin(self):
        return self.role == ROLE_ADMIN

    def can_create_posts(self):
        return self.role >= ROLE_CREATOR  # Criadores e admins podem criar posts

    def __repr__(self):
        return f'<User {self.username}>'


class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(120), nullable=False)
    content = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, index=True, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))

    def __repr__(self):
        return f'<Post {self.title}>'

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'content': self.content,
            'timestamp': self.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
            'author': self.author.username if self.author else 'Unknown'
        }


class Resource(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    descricao = db.Column(db.Text)
    skill = db.Column(db.String(200))
    last_acept = db.Column(db.DateTime, default=None)
    avaliation = db.Column(
        db.String(100))  # Exemplo: "Excelente", "Média", "Ruim"

    def __repr__(self):
        return f'<Resource {self.nome}>'
