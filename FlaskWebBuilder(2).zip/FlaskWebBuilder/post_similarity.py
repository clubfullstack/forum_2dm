import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from models import Post
import logging


def get_similar_posts(query, num_results=5):
    """
    Find posts similar to the query text using TF-IDF and cosine similarity.
    
    Args:
        query (str): The search query text
        num_results (int): Number of results to return
        
    Returns:
        list: A list of dictionaries containing post information and similarity scores
    """
    # Get all posts from the database
    posts = Post.query.all()

    if not posts:
        logging.warning("No posts found in database")
        return []

    # Create a list of post texts (title + content)
    post_texts = [f"{post.title} {post.content}" for post in posts]
    post_ids = [post.id for post in posts]

    # Create a TF-IDF vectorizer
    vectorizer = TfidfVectorizer(stop_words='english')

    # Add the query to the documents so it gets vectorized along with posts
    all_texts = post_texts + [query]

    try:
        # Calculate TF-IDF vectors for all texts
        tfidf_matrix = vectorizer.fit_transform(all_texts)

        # Get the query vector (last one in the matrix)
        query_vector = tfidf_matrix[-1:]

        # Calculate cosine similarity between query and all posts
        similarity_scores = cosine_similarity(query_vector,
                                              tfidf_matrix[:-1]).flatten()

        # Create a DataFrame with post information and similarity scores
        results_df = pd.DataFrame({
            'post_id': post_ids,
            'similarity_score': similarity_scores
        })

        # Sort by similarity score (descending) and take top results
        results_df = results_df.sort_values('similarity_score',
                                            ascending=False).head(num_results)

        # Only keep posts with positive similarity scores
        results_df = results_df[results_df['similarity_score'] > 0]

        # Format results as a list of dictionaries with post details
        results = []
        for _, row in results_df.iterrows():
            post = Post.query.get(row['post_id'])

            if post:
                results.append({
                    'id':
                    post.id,
                    'title':
                    post.title,
                    'content':
                    post.content,
                    'author':
                    post.author.username if post.author else 'Unknown',
                    'timestamp':
                    post.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                    'similarity_score':
                    round(row['similarity_score'] * 100,
                          2)  # Convert to percentage
                })

        return results

    except Exception as e:
        logging.error(f"Error in get_similar_posts: {str(e)}")
        raise
